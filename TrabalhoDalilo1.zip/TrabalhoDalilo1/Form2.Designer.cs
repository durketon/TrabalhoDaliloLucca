﻿namespace TrabalhoDalilo1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "600-tibia.jpg");
            this.imageList1.Images.SetKeyName(1, "5d1ca6a47e696c05dd4f1e92.jpg");
            this.imageList1.Images.SetKeyName(2, "img_poster_muorigin.jpg");
            this.imageList1.Images.SetKeyName(3, "guitar-hero-iii-legends-of-rock-pc-jogo-envio-imediato-D_NQ_NP_956917-MLB27071281" +
        "462_032018-F.jpg");
            this.imageList1.Images.SetKeyName(4, "Tekken_5_-_North-american_cover.jpg");
            this.imageList1.Images.SetKeyName(5, "devil-may-cry-3-ps2-dvd-D_NQ_NP_631222-MLB27823849174_072018-F.jpg");
            this.imageList1.Images.SetKeyName(6, "download.png");
            this.imageList1.Images.SetKeyName(7, "590dd6ccae653a041054f1aa.jpg");
            this.imageList1.Images.SetKeyName(8, "4092d7cefe.jpg");
            this.imageList1.Images.SetKeyName(9, "UNCHARTED-4-A-Thiefs-End.jpg");
            this.imageList1.Images.SetKeyName(10, "Dota 2.jpg");
            this.imageList1.Images.SetKeyName(11, "0c674c9afc.jpg");
            this.imageList1.Images.SetKeyName(12, "Capa_Pes_2019.png");
            this.imageList1.Images.SetKeyName(13, "RW9Cpk.jpg");
            this.imageList1.Images.SetKeyName(14, "counter-strike-global-offensive-pc-compare-cd-keys-prices-keyhub.jpg");
            this.imageList1.Images.SetKeyName(15, "GameBox.jpg");
            // 
            // button3
            // 
            this.button3.BackgroundImage = global::TrabalhoDalilo1.Properties.Resources.cor;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(655, 393);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(151, 76);
            this.button3.TabIndex = 3;
            this.button3.Text = "Selecionar";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.Button3_Click);
            this.button3.MouseEnter += new System.EventHandler(this.Button3_MouseEnter);
            this.button3.MouseLeave += new System.EventHandler(this.Button3_MouseLeave);
            // 
            // button2
            // 
            this.button2.BackgroundImage = global::TrabalhoDalilo1.Properties.Resources.cor_rosa;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(858, 393);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(151, 76);
            this.button2.TabIndex = 2;
            this.button2.Text = "Avançar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            this.button2.MouseEnter += new System.EventHandler(this.Button2_MouseEnter);
            this.button2.MouseLeave += new System.EventHandler(this.Button2_MouseLeave);
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::TrabalhoDalilo1.Properties.Resources.cor_azulbb1;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(453, 393);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(151, 76);
            this.button1.TabIndex = 1;
            this.button1.Text = "Voltar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            this.button1.MouseEnter += new System.EventHandler(this.Button1_MouseEnter);
            this.button1.MouseLeave += new System.EventHandler(this.Button1_MouseLeave);
            // 
            // label1
            // 
            this.label1.ImageIndex = 0;
            this.label1.ImageList = this.imageList1;
            this.label1.Location = new System.Drawing.Point(602, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(256, 256);
            this.label1.TabIndex = 0;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::TrabalhoDalilo1.Properties.Resources._005f27ea_28c5_4935_8c00_07c36b53b0ee;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1456, 653);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}