﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TrabalhoDalilo1
{
    public partial class Form2 : Form
    {
        String futebol = "Futebol";
        String aventura = "Aventura";
        String fps = "FPS";
        String rpg = "RPG";
        String mmo = "MMO";
        String corrida = "Corrida";
        String moba = "MOBA";
        String musica = "Musica";
        String luta = "Luta";

        int cont = -1;
        int futebol1 = 0;
        int aventura1 = 0;
        int fps1 = 0;
        int rpg1 = 0;
        int mmo1 = 0;
        int corrida1 = 0;
        int moba1 = 0;
        int musica1 = 0;
        int luta1 = 0;
        int index = 0;


        public Form2()
        {
            InitializeComponent();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            cont++;
            if (index == 0)
            {
                mmo1++;
                rpg1++;
            }
            index++;
            if (index == 1)
            {
                aventura1++;
                label1.ImageIndex = index;
            }
            if (index == 2)
            {
                rpg1++;
                mmo1++;
                label1.ImageIndex = index;
            }
            if (index == 3)
            {
                musica1++;
                label1.ImageIndex = index;
            }

            if (index == 4)
            {
                luta1++;
                label1.ImageIndex = index;
            }

            if (index == 5)
            {
                aventura1++;
                label1.ImageIndex = index;
            }
            if (index == 6)
            {
                luta1++;
                label1.ImageIndex = index;
            }
            if (index == 7)
            {
                fps1++;
                label1.ImageIndex = index;
            }
            if (index == 8)
            {
                aventura1++;
                rpg1++;
                label1.ImageIndex = index;
            }
            if (index == 9)
            {
                aventura1++;
                rpg1++;
                label1.ImageIndex = index;
            }
            if (index == 10)
            {
                moba1++;
                label1.ImageIndex = index;
            }
            if (index == 11)
            {
                futebol1++;
                label1.ImageIndex = index;
            }
            if (index == 12)
            {
                futebol1++;
                label1.ImageIndex = index;
            }
            if (index == 13)
            {
                corrida1++;
                label1.ImageIndex = index;
            }
            if (index == 14)
            {
                fps1++;
                label1.ImageIndex = index;
            }
            if (index == 15)
            {
                moba1++;
                label1.ImageIndex = index;
            }
            if(cont == 15)
            {
                moba1++;
                MessageBox.Show(mmo + rpg + ": " +rpg1 + "\n" + moba + ": " + moba1 + "\n" + aventura + ": " + aventura1 + "\n" + musica + ": " + musica1 + "\n" +luta + ": "  + luta1 + 
                    "\n" + fps +": " + fps1 + "\n" +rpg + ": " + rpg1 + "\n" + corrida + ": " + corrida1 + "\n" + futebol + ": " + futebol1 + "\n","Tipos de jogos que" +
                    " você gosta");
                this.Close();
            }
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            index++;
            cont++;
            if (index == 1)
            {
                label1.ImageIndex = index;
            }
            if (index == 2)
            {
                label1.ImageIndex = index;
            }
            if (index == 3)
            {
                label1.ImageIndex = index;
            }

            if (index == 4)
            {
                label1.ImageIndex = index;
            }

            if (index == 5)
            {
                label1.ImageIndex = index;
            }
            if (index == 6)
            {
                label1.ImageIndex = index;
            }
            if (index == 7)
            {
                label1.ImageIndex = index;
            }
            if (index == 8)
            {
                label1.ImageIndex = index;
            }
            if (index == 9)
            {
                label1.ImageIndex = index;
            }
            if (index == 10)
            {
                label1.ImageIndex = index;
            }
            if (index == 11)
            {
                label1.ImageIndex = index;
            }
            if (index == 12)
            {
                label1.ImageIndex = index;
            }
            if (index == 13)
            {
                label1.ImageIndex = index;
            }
            if (index == 14)
            {
                label1.ImageIndex = index;
            }
            if (index == 15)
            {
                label1.ImageIndex = index;
            }
            if (cont > 14 )
            {
                MessageBox.Show(mmo + rpg + ": " + rpg1 + "\n" + moba + ": " + moba1 + "\n" + aventura + ": " + aventura1 + "\n" + musica + ": " + musica1 + "\n" + luta + ": " + luta1 +
                    "\n" + fps + ": " + fps1 + "\n" + rpg + ": " + rpg1 + "\n" + corrida + ": " + corrida1 + "\n" + futebol + ": " + futebol1 + "\n","Tipos de jogos que" +
                    " você gosta");
                this.Close();
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            index--;

            if(index == 0)
            {
                label1.ImageIndex = index;
            }

            if (index == 1)
            {
                label1.ImageIndex = index;
            }
            if (index == 2)
            {
                label1.ImageIndex = index;
            }
            if (index == 3)
            {
                label1.ImageIndex = index;
            }

            if (index == 4)
            {
                label1.ImageIndex = index;
            }

            if (index == 5)
            {
                label1.ImageIndex = index;
            }
            if (index == 6)
            {
                label1.ImageIndex = index;
            }
            if (index == 7)
            {
                label1.ImageIndex = index;
            }
            if (index == 8)
            {
                label1.ImageIndex = index;
            }
            if (index == 9)
            {
                label1.ImageIndex = index;
            }
            if (index == 10)
            {
                label1.ImageIndex = index;
            }
            if (index == 11)
            {
                label1.ImageIndex = index;
            }
            if (index == 12)
            {
                label1.ImageIndex = index;
            }
            if (index == 13)
            {
                label1.ImageIndex = index;
            }
            if (index == 14)
            {
                label1.ImageIndex = index;
            }
            if (index == 15)
            {
                label1.ImageIndex = index;
            }
            if(index < 0)
            {
                MessageBox.Show("Nã há nada antes desta imagem");
            }

        }

        private void Button2_MouseEnter(object sender, EventArgs e)
        {
            button2.FlatAppearance.BorderSize = 3;
            button2.FlatAppearance.BorderColor = Color.DeepPink;
        }

        private void Button2_MouseLeave(object sender, EventArgs e)
        {
            button2.FlatAppearance.BorderSize = 3;
            button2.FlatAppearance.BorderColor = Color.LightGoldenrodYellow;
        }

        private void Button3_MouseEnter(object sender, EventArgs e)
        {
            button3.FlatAppearance.BorderSize = 3;
            button3.FlatAppearance.BorderColor = Color.DarkGreen;
        }

        private void Button3_MouseLeave(object sender, EventArgs e)
        {
            button3.FlatAppearance.BorderSize = 3;
            button3.FlatAppearance.BorderColor = Color.LightGoldenrodYellow;
        }

        private void Button1_MouseEnter(object sender, EventArgs e)
        {
            button1.FlatAppearance.BorderSize = 3;
            button1.FlatAppearance.BorderColor = Color.DarkBlue;
        }

        private void Button1_MouseLeave(object sender, EventArgs e)
        {
            button1.FlatAppearance.BorderSize = 3;
            button1.FlatAppearance.BorderColor = Color.LightGoldenrodYellow;
        }
    }
    }

